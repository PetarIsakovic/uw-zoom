var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var approved_images_exports = {};
__export(approved_images_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(approved_images_exports);
var import_bans = require("./_lib/bans.js");
var import_http = require("./_lib/http.js");
var import_image_catalog = require("./_lib/image-catalog.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET"]);
  await (0, import_bans.requireNotBanned)(event, "playing the game");
  const origin = (0, import_http.getOrigin)(event);
  const images = await (0, import_image_catalog.listPlayableCatalogImages)(origin);
  return (0, import_http.json)(200, {
    images,
    source: images.every((image) => image.source === "demo") ? "demo" : "catalog"
  }, {
    "Cache-Control": "private, max-age=45, stale-while-revalidate=120"
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
