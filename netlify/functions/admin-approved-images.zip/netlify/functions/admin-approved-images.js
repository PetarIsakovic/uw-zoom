var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_approved_images_exports = {};
__export(admin_approved_images_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_approved_images_exports);
var import_admin = require("./_lib/admin.js");
var import_http = require("./_lib/http.js");
var import_image_catalog = require("./_lib/image-catalog.js");
var import_storage = require("./_lib/storage.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "POST", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET", "POST"]);
  (0, import_admin.requireAdmin)(event);
  if (event.httpMethod === "GET") {
    const origin2 = (0, import_http.getOrigin)(event);
    return (0, import_http.json)(200, {
      images: await (0, import_image_catalog.listAdminCatalogImages)(origin2)
    });
  }
  const body = (0, import_http.parseJsonBody)(event);
  const id = String(body.id || "").trim();
  const action = String(body.action || "").trim().toLowerCase();
  const origin = (0, import_http.getOrigin)(event);
  if (!id || !/^[a-z0-9-]{4,80}$/i.test(id)) {
    throw new import_http.HttpError(400, "A valid approved image id is required.");
  }
  if (!["update", "delete"].includes(action)) {
    throw new import_http.HttpError(400, "Action must be update or delete.");
  }
  if ((0, import_image_catalog.isDemoCatalogImage)(id)) {
    if (action === "delete") {
      await (0, import_image_catalog.deleteDemoCatalogImage)(id);
      return (0, import_http.json)(200, {
        success: true,
        action,
        id
      });
    }
    return (0, import_http.json)(200, {
      success: true,
      action,
      image: await (0, import_image_catalog.updateDemoCatalogImage)(origin, id, body)
    });
  }
  const metadataKey = (0, import_storage.approvedMetadataKey)(id);
  const record = await (0, import_storage.getJson)(metadataKey);
  if (!record) {
    throw new import_http.HttpError(404, "That approved image no longer exists.");
  }
  if (action === "delete") {
    await (0, import_storage.deleteObject)(record.imageKey);
    await (0, import_storage.deleteObject)(metadataKey);
    return (0, import_http.json)(200, {
      success: true,
      action,
      id
    });
  }
  const answer = normalizeAnswer(body.answer);
  const acceptedAnswers = normalizeAcceptedAnswers(body.acceptedAnswers, answer);
  if (!answer) {
    throw new import_http.HttpError(400, "The main answer is required.");
  }
  const updatedRecord = __spreadProps(__spreadValues({}, record), {
    answer,
    acceptedAnswers,
    updatedAt: new Date().toISOString()
  });
  await (0, import_storage.putJson)(metadataKey, updatedRecord);
  return (0, import_http.json)(200, {
    success: true,
    action,
    image: updatedRecord
  });
});
function normalizeAnswer(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 80);
}
function normalizeAcceptedAnswers(value, mainAnswer = "") {
  const parsed = Array.isArray(value) ? value : String(value || "").split(/[\n,]/).map((item) => item.trim());
  const seen = /* @__PURE__ */ new Set();
  const normalizedMain = normalizeComparable(mainAnswer);
  const unique = [];
  for (const entry of parsed) {
    const trimmed = String(entry || "").trim().replace(/\s+/g, " ").slice(0, 80);
    const comparable = normalizeComparable(trimmed);
    if (!trimmed || !comparable || comparable === normalizedMain || seen.has(comparable)) {
      continue;
    }
    seen.add(comparable);
    unique.push(trimmed);
  }
  return unique;
}
function normalizeComparable(value) {
  return String(value || "").normalize("NFKD").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
