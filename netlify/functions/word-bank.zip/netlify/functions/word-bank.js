var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var word_bank_exports = {};
__export(word_bank_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(word_bank_exports);
var import_word_bank = require("../../shared/word-bank.js");
var import_bans = require("./_lib/bans.js");
var import_http = require("./_lib/http.js");
var import_image_catalog = require("./_lib/image-catalog.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET"]);
  await (0, import_bans.requireNotBanned)(event, "playing the game");
  const combined = [...import_word_bank.WORD_BANK];
  for (const item of await (0, import_image_catalog.listCatalogAnswerEntries)()) {
    if (item?.answer) {
      combined.push(item.answer);
    }
    for (const alias of item?.acceptedAnswers || []) {
      combined.push(alias);
    }
  }
  const unique = [...(0, import_word_bank.createWordBankIndex)(combined).values()].sort((left, right) => left.localeCompare(right));
  return (0, import_http.json)(200, {
    words: unique
  }, {
    "Cache-Control": "private, max-age=45, stale-while-revalidate=120"
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
