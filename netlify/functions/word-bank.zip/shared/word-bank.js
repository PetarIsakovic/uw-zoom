var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var word_bank_exports = {};
__export(word_bank_exports, {
  WORD_BANK: () => WORD_BANK,
  createWordBankIndex: () => createWordBankIndex,
  isWordBankEntry: () => isWordBankEntry,
  normalizeWordBankValue: () => normalizeWordBankValue,
  resolveInWordBank: () => resolveInWordBank,
  resolveWordBankEntry: () => resolveWordBankEntry,
  searchInWordBank: () => searchInWordBank,
  searchWordBank: () => searchWordBank
});
module.exports = __toCommonJS(word_bank_exports);
const WORD_BANK = buildWordBank([
  "University of Waterloo",
  "Waterloo",
  "UW",
  "UWaterloo",
  "Waterloo Warriors",
  "Warriors",
  "goose",
  "geese",
  "gosling",
  "WatCard",
  "Quest",
  "Learn",
  "co-op",
  "coop",
  "engineering ring",
  "iron ring",
  "pink tie",
  "Dana Porter Library",
  "Dana Porter",
  "DP Library",
  "DP",
  "Davis Centre",
  "DC",
  "DC Library",
  "Student Life Centre",
  "SLC",
  "Physical Activities Complex",
  "PAC",
  "SLC/PAC",
  "Mathematics and Computer",
  "Mathematics and Computer Building",
  "MC",
  "Physics",
  "PHY",
  "Quantum Nano Centre",
  "QNC",
  "Carl Pollock Hall",
  "CPH",
  "Tatham Centre",
  "TC",
  "South Campus Hall",
  "SCH",
  "Needles Hall",
  "NH",
  "Hagey Hall",
  "HH",
  "Arts Quad",
  "CIF",
  "E7",
  "E5",
  "E3",
  "E2",
  "EV3",
  "RCH",
  "Village 1",
  "V1",
  "CMH",
  "Claudette Millar Hall",
  "UWP",
  "MKV",
  "REV",
  "Ron Eydt Village",
  "Conrad Grebel",
  "Renison",
  "United College",
  "St. Jerome's",
  "St Jeromes",
  "MathSoc",
  "EngSoc",
  "WUSA",
  "Bomber",
  "ION",
  "ION train",
  "LRT",
  "GRT bus",
  "black and gold",
  "Goose statue",
  "Turnkey Desk",
  "ring road"
]);
const WORD_BANK_INDEX = createWordBankIndex(WORD_BANK);
function normalizeWordBankValue(value) {
  return String(value || "").normalize("NFKD").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}
function resolveWordBankEntry(value) {
  return WORD_BANK_INDEX.get(normalizeWordBankValue(value)) || null;
}
function isWordBankEntry(value) {
  return Boolean(resolveWordBankEntry(value));
}
function searchWordBank(query, limit = 8) {
  return searchInWordBank(WORD_BANK, query, limit);
}
function createWordBankIndex(values) {
  return new Map(values.map((entry) => [normalizeWordBankValue(entry), entry]));
}
function resolveInWordBank(values, value) {
  return createWordBankIndex(values).get(normalizeWordBankValue(value)) || null;
}
function searchInWordBank(values, query, limit = 8) {
  const normalizedQuery = normalizeWordBankValue(query);
  if (!normalizedQuery) {
    return [];
  }
  const startsWith = [];
  const includes = [];
  for (const entry of values) {
    const normalizedEntry = normalizeWordBankValue(entry);
    if (normalizedEntry.startsWith(normalizedQuery)) {
      startsWith.push(entry);
      continue;
    }
    if (normalizedEntry.includes(normalizedQuery)) {
      includes.push(entry);
    }
  }
  return [...startsWith, ...includes].slice(0, limit);
}
function buildWordBank(values) {
  const seen = /* @__PURE__ */ new Set();
  const unique = [];
  for (const value of values) {
    const trimmed = String(value || "").trim();
    const normalized = normalizeWordBankValue(trimmed);
    if (!trimmed || seen.has(normalized)) {
      continue;
    }
    seen.add(normalized);
    unique.push(trimmed);
  }
  return unique;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  WORD_BANK,
  createWordBankIndex,
  isWordBankEntry,
  normalizeWordBankValue,
  resolveInWordBank,
  resolveWordBankEntry,
  searchInWordBank,
  searchWordBank
});
