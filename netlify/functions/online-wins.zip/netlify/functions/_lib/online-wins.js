var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var online_wins_exports = {};
__export(online_wins_exports, {
  deleteOnlineWinLeader: () => deleteOnlineWinLeader,
  loadOnlineWinLeaders: () => loadOnlineWinLeaders,
  normalizeLeader: () => normalizeLeader
});
module.exports = __toCommonJS(online_wins_exports);
var import_node_crypto = require("node:crypto");
var import_avatar_selection = require("./avatar-selection.js");
var import_censor = require("./censor.js");
var import_storage = require("./storage.js");
const ONLINE_WINS_KEY = "app/online-duel/wins.json";
async function loadOnlineWinLeaders() {
  if (!(0, import_storage.storageConfigured)()) {
    return [];
  }
  const payload = await (0, import_storage.getJson)(ONLINE_WINS_KEY);
  const leaders = Array.isArray(payload?.leaders) ? payload.leaders : [];
  return leaders.map(normalizeLeader).filter((entry) => entry.name).sort((left, right) => right.wins - left.wins || left.name.localeCompare(right.name));
}
async function deleteOnlineWinLeader(entryId) {
  if (!(0, import_storage.storageConfigured)()) {
    return [];
  }
  const normalizedId = normalizeId(entryId);
  const nextLeaders = (await loadOnlineWinLeaders()).filter((entry) => entry.id !== normalizedId);
  await (0, import_storage.putJson)(ONLINE_WINS_KEY, {
    updatedAt: new Date().toISOString(),
    leaders: nextLeaders.map((entry) => ({
      name: entry.name,
      avatar: (0, import_avatar_selection.normalizeAvatarSelection)(entry.avatar),
      wins: normalizeWins(entry.wins)
    }))
  });
  return nextLeaders;
}
function normalizeLeader(value) {
  const name = normalizeName(value?.name);
  return {
    id: createLeaderId(name),
    name,
    avatar: (0, import_avatar_selection.normalizeAvatarSelection)(value?.avatar),
    wins: normalizeWins(value?.wins)
  };
}
function normalizeName(value) {
  return (0, import_censor.censorProfanity)(value, { maxLength: 32 });
}
function normalizeWins(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
}
function createLeaderId(name) {
  return (0, import_node_crypto.createHash)("sha256").update(String(name || "")).digest("hex").slice(0, 24);
}
function normalizeId(value) {
  const normalized = String(value || "").trim().toLowerCase();
  return /^[a-z0-9-]{8,64}$/.test(normalized) ? normalized : "";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  deleteOnlineWinLeader,
  loadOnlineWinLeaders,
  normalizeLeader
});
