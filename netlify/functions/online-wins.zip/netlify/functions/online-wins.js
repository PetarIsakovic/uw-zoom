var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var online_wins_exports = {};
__export(online_wins_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(online_wins_exports);
var import_http = require("./_lib/http.js");
var import_online_wins = require("./_lib/online-wins.js");
var import_storage = require("./_lib/storage.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET"]);
  if (!(0, import_storage.storageConfigured)()) {
    return (0, import_http.json)(200, {
      leaders: [],
      source: "demo"
    });
  }
  return (0, import_http.json)(200, {
    leaders: (await (0, import_online_wins.loadOnlineWinLeaders)()).slice(0, 25),
    source: "storage"
  }, {
    "Cache-Control": "public, max-age=60, s-maxage=180, stale-while-revalidate=300"
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
