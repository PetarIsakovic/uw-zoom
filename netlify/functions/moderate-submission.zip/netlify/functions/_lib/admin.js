var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_exports = {};
__export(admin_exports, {
  requireAdmin: () => requireAdmin
});
module.exports = __toCommonJS(admin_exports);
var import_http = require("./http.js");
function requireAdmin(event) {
  const expectedKey = process.env.UWZ_ADMIN_KEY;
  if (!expectedKey) {
    throw new import_http.HttpError(503, "UWZ_ADMIN_KEY is not configured.");
  }
  const headerValue = event.headers["x-admin-key"] || event.headers["X-Admin-Key"] || readAuthorizationHeader(event.headers.authorization || event.headers.Authorization);
  if (headerValue !== expectedKey) {
    throw new import_http.HttpError(401, "Invalid admin key.");
  }
}
function readAuthorizationHeader(value) {
  if (!value) {
    return "";
  }
  const match = value.match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : "";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  requireAdmin
});
