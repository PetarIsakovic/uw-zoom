var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var submit_image_exports = {};
__export(submit_image_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(submit_image_exports);
var import_http = require("./_lib/http.js");
var import_bans = require("./_lib/bans.js");
var import_ip = require("./_lib/ip.js");
var import_rate_limit = require("./_lib/rate-limit.js");
var import_storage = require("./_lib/storage.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["POST", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["POST"]);
  await (0, import_bans.requireNotBanned)(event, "uploading images");
  await (0, import_rate_limit.requireRateLimit)(event, "submit-image", {
    maxRequests: 10,
    windowMs: 10 * 60 * 1e3,
    message: "Too many upload submissions from this connection. Try again in a few minutes."
  });
  const body = (0, import_http.parseJsonBody)(event);
  const id = String(body.id || "").trim();
  const imageKey = String(body.imageKey || "").trim();
  const uploaderName = normalizeUploaderName(body.uploaderName);
  const answer = String(body.answer || "").trim();
  const submitterIp = (0, import_ip.getClientIp)(event);
  if (!id || !/^[a-z0-9-]{20,80}$/i.test(id)) {
    throw new import_http.HttpError(400, "A valid submission id is required.");
  }
  if (!imageKey.startsWith(`pending/images/${id}`)) {
    throw new import_http.HttpError(400, "The uploaded image key does not match this submission.");
  }
  if (!answer) {
    throw new import_http.HttpError(400, "The answer is required.");
  }
  if (!uploaderName) {
    throw new import_http.HttpError(400, "The uploader name is required.");
  }
  const metadata = await (0, import_storage.getObjectMetadata)(imageKey);
  if (!metadata) {
    throw new import_http.HttpError(400, "Upload the image before creating the submission.");
  }
  try {
    (0, import_storage.validateImageType)(metadata.contentType);
    (0, import_storage.validateImageSize)(metadata.contentLength);
  } catch (error) {
    await (0, import_storage.deleteObject)(imageKey).catch(() => {
    });
    if (error instanceof import_http.HttpError) {
      const { maxUploadMb } = (0, import_storage.getStorageConfig)();
      throw new import_http.HttpError(error.statusCode, metadata.contentLength > maxUploadMb * 1024 * 1024 ? `That file was too large. Keep uploads under ${maxUploadMb} MB.` : "Only JPEG, PNG, or WebP uploads are supported.");
    }
    throw error;
  }
  const submission = {
    id,
    answer,
    acceptedAnswers: [],
    uploaderName,
    submitterIp,
    uploaderEmail: "",
    notes: "",
    imageKey,
    submittedAt: new Date().toISOString(),
    status: "pending"
  };
  await (0, import_storage.putJson)((0, import_storage.pendingMetadataKey)(id), submission);
  return (0, import_http.json)(200, {
    success: true,
    submission
  });
});
function normalizeUploaderName(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 60);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
