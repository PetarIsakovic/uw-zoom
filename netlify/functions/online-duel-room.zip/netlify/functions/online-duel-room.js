var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var online_duel_room_exports = {};
__export(online_duel_room_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(online_duel_room_exports);
var import_http = require("./_lib/http.js");
var import_bans = require("./_lib/bans.js");
var import_online_duel = require("./_lib/online-duel.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET"]);
  await (0, import_bans.requireNotBanned)(event, "joining online matches");
  const playerId = String(event.queryStringParameters?.playerId || "").trim();
  const token = String(event.queryStringParameters?.token || "").trim();
  if (!playerId || !token) {
    throw new import_http.HttpError(400, "Online room status needs both playerId and token.");
  }
  const payload = await (0, import_online_duel.getOnlineDuelState)({
    origin: (0, import_http.getOrigin)(event),
    playerId,
    token
  });
  return (0, import_http.json)(200, payload);
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
