var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_online_stats_exports = {};
__export(admin_online_stats_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_online_stats_exports);
var import_admin = require("./_lib/admin.js");
var import_http = require("./_lib/http.js");
var import_online_duel = require("./_lib/online-duel.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET"]);
  (0, import_admin.requireAdmin)(event);
  const payload = await (0, import_online_duel.loadOnlineDuelAdminStats)();
  return (0, import_http.json)(200, payload);
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
