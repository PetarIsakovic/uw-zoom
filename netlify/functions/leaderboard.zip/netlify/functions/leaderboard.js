var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var leaderboard_exports = {};
__export(leaderboard_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(leaderboard_exports);
var import_http = require("./_lib/http.js");
var import_avatar_selection = require("./_lib/avatar-selection.js");
var import_leaderboard = require("./_lib/leaderboard.js");
var import_bans = require("./_lib/bans.js");
var import_censor = require("./_lib/censor.js");
var import_ip = require("./_lib/ip.js");
var import_rate_limit = require("./_lib/rate-limit.js");
var import_storage = require("./_lib/storage.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "POST", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET", "POST"]);
  if (event.httpMethod === "GET") {
    const entries2 = await (0, import_leaderboard.loadLeaderboardEntries)();
    return (0, import_http.json)(200, {
      entries: entries2.map(toPublicEntry),
      highScore: (0, import_leaderboard.getHighScore)(entries2),
      source: (0, import_storage.storageConfigured)() ? "storage" : "demo"
    }, {
      "Cache-Control": "public, max-age=30, s-maxage=120, stale-while-revalidate=300"
    });
  }
  (0, import_storage.requireStorage)();
  await (0, import_bans.requireNotBanned)(event, "saving leaderboard entries");
  await (0, import_rate_limit.requireRateLimit)(event, "leaderboard-save", {
    maxRequests: 25,
    windowMs: 10 * 60 * 1e3,
    message: "Too many leaderboard submissions from this connection. Try again shortly."
  });
  const body = (0, import_http.parseJsonBody)(event);
  const name = normalizeName(body.name);
  const score = normalizeScore(body.score);
  const durationMs = normalizeDurationMs(body.durationMs);
  const avatar = (0, import_avatar_selection.normalizeAvatarSelection)(body.avatar);
  const result = body.result === "win" ? "win" : "loss";
  const ip = (0, import_ip.getClientIp)(event);
  if (!name) {
    throw new import_http.HttpError(400, "Type your name before saving your run.");
  }
  const entries = await (0, import_leaderboard.saveLeaderboardEntry)({
    name,
    avatar,
    score,
    durationMs,
    result,
    ip
  });
  return (0, import_http.json)(200, {
    success: true,
    entries: entries.map(toPublicEntry),
    highScore: (0, import_leaderboard.getHighScore)(entries)
  });
});
function normalizeName(value) {
  return (0, import_censor.censorProfanity)(value, { maxLength: 32 });
}
function normalizeScore(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
}
function normalizeDurationMs(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
}
function toPublicEntry(entry) {
  return {
    id: entry.id,
    name: entry.name,
    avatar: entry.avatar,
    score: entry.score,
    durationMs: entry.durationMs,
    result: entry.result,
    playedAt: entry.playedAt
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
