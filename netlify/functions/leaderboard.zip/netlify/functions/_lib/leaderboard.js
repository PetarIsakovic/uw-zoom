var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var leaderboard_exports = {};
__export(leaderboard_exports, {
  compareLeaderboardEntries: () => compareLeaderboardEntries,
  deleteLeaderboardEntry: () => deleteLeaderboardEntry,
  getHighScore: () => getHighScore,
  loadLeaderboardEntries: () => loadLeaderboardEntries,
  normalizeEntry: () => normalizeEntry,
  saveLeaderboardEntry: () => saveLeaderboardEntry
});
module.exports = __toCommonJS(leaderboard_exports);
var import_node_crypto = require("node:crypto");
var import_avatar_selection = require("./avatar-selection.js");
var import_censor = require("./censor.js");
var import_storage = require("./storage.js");
const LEADERBOARD_KEY = "app/leaderboard/top-streaks.json";
const LEADERBOARD_MAX_ENTRIES = 10;
async function loadLeaderboardEntries() {
  if (!(0, import_storage.storageConfigured)()) {
    return [];
  }
  const payload = await (0, import_storage.getJson)(LEADERBOARD_KEY);
  const entries = Array.isArray(payload?.entries) ? payload.entries : [];
  return entries.filter(isValidEntry).map(normalizeEntry).sort(compareLeaderboardEntries);
}
async function saveLeaderboardEntry(payload) {
  const entries = await loadLeaderboardEntries();
  entries.push(normalizeEntry(__spreadProps(__spreadValues({}, payload), {
    id: (0, import_node_crypto.randomUUID)(),
    playedAt: new Date().toISOString()
  })));
  entries.sort(compareLeaderboardEntries);
  const trimmedEntries = entries.slice(0, LEADERBOARD_MAX_ENTRIES);
  await (0, import_storage.putJson)(LEADERBOARD_KEY, {
    updatedAt: new Date().toISOString(),
    entries: trimmedEntries
  });
  return trimmedEntries;
}
function getHighScore(entries) {
  return normalizeScore(entries[0]?.score);
}
function compareLeaderboardEntries(left, right) {
  const scoreDifference = normalizeScore(right.score) - normalizeScore(left.score);
  if (scoreDifference !== 0) {
    return scoreDifference;
  }
  const durationDifference = normalizeDurationMs(left.durationMs) - normalizeDurationMs(right.durationMs);
  if (durationDifference !== 0) {
    return durationDifference;
  }
  return new Date(right.playedAt || 0).getTime() - new Date(left.playedAt || 0).getTime();
}
function normalizeEntry(value) {
  return {
    id: normalizeEntryId(value),
    name: normalizeName(value?.name),
    ip: normalizeIpAddress(value?.ip),
    avatar: (0, import_avatar_selection.normalizeAvatarSelection)(value?.avatar),
    score: normalizeScore(value?.score),
    durationMs: normalizeDurationMs(value?.durationMs, 0),
    result: value?.result === "win" ? "win" : "loss",
    playedAt: normalizeTimestamp(value?.playedAt)
  };
}
async function deleteLeaderboardEntry(entryId) {
  if (!(0, import_storage.storageConfigured)()) {
    return [];
  }
  const normalizedId = normalizeExplicitId(entryId);
  const entries = await loadLeaderboardEntries();
  const nextEntries = entries.filter((entry) => entry.id !== normalizedId);
  await (0, import_storage.putJson)(LEADERBOARD_KEY, {
    updatedAt: new Date().toISOString(),
    entries: nextEntries
  });
  return nextEntries;
}
function isValidEntry(value) {
  return value && Number.isFinite(Number(value.score));
}
function normalizeName(value) {
  const normalized = (0, import_censor.censorProfanity)(value, { maxLength: 32 });
  return normalized || "Anonymous";
}
function normalizeScore(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
}
function normalizeDurationMs(value, fallback = Number.POSITIVE_INFINITY) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : fallback;
}
function normalizeTimestamp(value) {
  const parsed = Date.parse(String(value || ""));
  return Number.isFinite(parsed) ? new Date(parsed).toISOString() : new Date().toISOString();
}
function normalizeEntryId(value) {
  const explicitId = normalizeExplicitId(value?.id);
  if (explicitId) {
    return explicitId;
  }
  const signature = JSON.stringify({
    name: normalizeName(value?.name),
    score: normalizeScore(value?.score),
    durationMs: normalizeDurationMs(value?.durationMs, 0),
    result: value?.result === "win" ? "win" : "loss",
    playedAt: normalizeTimestamp(value?.playedAt)
  });
  return (0, import_node_crypto.createHash)("sha256").update(signature).digest("hex").slice(0, 24);
}
function normalizeExplicitId(value) {
  const normalized = String(value || "").trim().toLowerCase();
  return /^[a-z0-9-]{8,64}$/.test(normalized) ? normalized : "";
}
function normalizeIpAddress(value) {
  return String(value || "").split(",")[0].trim().replace(/^\[|\]$/g, "").replace(/^::ffff:/i, "").slice(0, 80) || "Unknown";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  compareLeaderboardEntries,
  deleteLeaderboardEntry,
  getHighScore,
  loadLeaderboardEntries,
  normalizeEntry,
  saveLeaderboardEntry
});
