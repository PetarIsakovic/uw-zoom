var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_bans_exports = {};
__export(admin_bans_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_bans_exports);
var import_admin = require("./_lib/admin.js");
var import_http = require("./_lib/http.js");
var import_bans = require("./_lib/bans.js");
var import_ip = require("./_lib/ip.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "POST", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET", "POST"]);
  (0, import_admin.requireAdmin)(event);
  if (event.httpMethod === "GET") {
    return (0, import_http.json)(200, {
      bans: await (0, import_bans.loadBannedIps)()
    });
  }
  const body = (0, import_http.parseJsonBody)(event);
  const action = String(body.action || "").trim().toLowerCase();
  const ip = (0, import_ip.normalizeIp)(body.ip);
  if (!ip || ip === "Unknown") {
    throw new import_http.HttpError(400, "A valid IP address is required.");
  }
  if (action === "ban") {
    return (0, import_http.json)(200, {
      success: true,
      bans: await (0, import_bans.banIp)(ip, {
        label: String(body.label || "").trim(),
        source: String(body.source || "").trim()
      })
    });
  }
  if (action === "unban") {
    return (0, import_http.json)(200, {
      success: true,
      bans: await (0, import_bans.unbanIp)(ip)
    });
  }
  throw new import_http.HttpError(400, "Action must be ban or unban.");
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
