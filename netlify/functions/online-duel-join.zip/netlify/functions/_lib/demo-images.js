var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var demo_images_exports = {};
__export(demo_images_exports, {
  buildDemoImages: () => buildDemoImages
});
module.exports = __toCommonJS(demo_images_exports);
function buildDemoImages(origin) {
  return [
    {
      id: "demo-watcard",
      answer: "WatCard",
      acceptedAnswers: ["wat card"],
      imageUrl: `${origin}/assets/demo/camera.svg`,
      source: "demo",
      focusX: 50,
      focusY: 50
    },
    {
      id: "demo-dana-porter",
      answer: "Dana Porter Library",
      acceptedAnswers: ["Dana Porter", "DP Library", "DP"],
      imageUrl: `${origin}/assets/demo/coffee.svg`,
      source: "demo",
      focusX: 50,
      focusY: 48
    },
    {
      id: "demo-goose",
      answer: "goose",
      acceptedAnswers: ["geese"],
      imageUrl: `${origin}/assets/demo/backpack.svg`,
      source: "demo",
      focusX: 50,
      focusY: 52
    },
    {
      id: "demo-ion",
      answer: "ION",
      acceptedAnswers: ["ION train", "LRT"],
      imageUrl: `${origin}/assets/demo/headphones.svg`,
      source: "demo",
      focusX: 50,
      focusY: 52
    }
  ];
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildDemoImages
});
