var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var avatar_selection_exports = {};
__export(avatar_selection_exports, {
  DEFAULT_AVATAR_SELECTION: () => DEFAULT_AVATAR_SELECTION,
  normalizeAvatarSelection: () => normalizeAvatarSelection
});
module.exports = __toCommonJS(avatar_selection_exports);
const DEFAULT_AVATAR_SELECTION = Object.freeze({
  body: 0,
  eyes: 0,
  mouth: 0,
  extra: 0
});
const MAX_AVATAR_INDEX = 999;
function normalizeAvatarSelection(value) {
  return {
    body: normalizeAvatarIndex(value?.body, DEFAULT_AVATAR_SELECTION.body),
    eyes: normalizeAvatarIndex(value?.eyes, DEFAULT_AVATAR_SELECTION.eyes),
    mouth: normalizeAvatarIndex(value?.mouth, DEFAULT_AVATAR_SELECTION.mouth),
    extra: normalizeAvatarIndex(value?.extra, DEFAULT_AVATAR_SELECTION.extra)
  };
}
function normalizeAvatarIndex(value, fallback) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) {
    return fallback;
  }
  return Math.min(Math.floor(parsed), MAX_AVATAR_INDEX);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DEFAULT_AVATAR_SELECTION,
  normalizeAvatarSelection
});
