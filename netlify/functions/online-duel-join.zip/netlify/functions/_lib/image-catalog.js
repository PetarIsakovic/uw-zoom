var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var image_catalog_exports = {};
__export(image_catalog_exports, {
  deleteDemoCatalogImage: () => deleteDemoCatalogImage,
  isDemoCatalogImage: () => isDemoCatalogImage,
  listAdminCatalogImages: () => listAdminCatalogImages,
  listCatalogAnswerEntries: () => listCatalogAnswerEntries,
  listPlayableCatalogImages: () => listPlayableCatalogImages,
  updateDemoCatalogImage: () => updateDemoCatalogImage
});
module.exports = __toCommonJS(image_catalog_exports);
var import_http = require("./http.js");
var import_demo_images = require("./demo-images.js");
var import_storage = require("./storage.js");
const DEMO_IMAGE_SETTINGS_KEY = "app/admin/demo-images.json";
const DEMO_SOURCE_LABEL = "Starter image";
const APPROVED_SOURCE_LABEL = "Approved upload";
const DEMO_UPLOADER_NAME = "Built-in starter set";
const DEMO_IMAGE_IDS = new Set((0, import_demo_images.buildDemoImages)("").map((image) => image.id));
function isDemoCatalogImage(id) {
  return DEMO_IMAGE_IDS.has(String(id || "").trim());
}
async function listPlayableCatalogImages(origin) {
  const [demoImages, approvedImages] = await Promise.all([
    listManagedDemoImages(origin),
    listStoredApprovedImages()
  ]);
  return [...demoImages, ...approvedImages];
}
async function listAdminCatalogImages(origin) {
  const [demoImages, approvedImages] = await Promise.all([
    listManagedDemoImages(origin, {
      forAdmin: true
    }),
    listStoredApprovedImages({
      forAdmin: true
    })
  ]);
  return [...demoImages, ...approvedImages];
}
async function listCatalogAnswerEntries() {
  const [demoImages, approvedImages] = await Promise.all([
    listManagedDemoImages(""),
    listStoredApprovedImages()
  ]);
  return [...demoImages, ...approvedImages].map((image) => ({
    id: image.id,
    source: image.source,
    answer: image.answer,
    acceptedAnswers: image.acceptedAnswers || []
  }));
}
async function updateDemoCatalogImage(origin, id, fields) {
  const normalizedId = String(id || "").trim();
  if (!isDemoCatalogImage(normalizedId)) {
    throw new import_http.HttpError(404, "That starter image does not exist.");
  }
  const answer = normalizeAnswer(fields.answer);
  if (!answer) {
    throw new import_http.HttpError(400, "The main answer is required.");
  }
  const acceptedAnswers = normalizeAcceptedAnswers(fields.acceptedAnswers, answer);
  const settings = await loadDemoImageSettings();
  const updatedAt = new Date().toISOString();
  settings[normalizedId] = __spreadProps(__spreadValues({}, settings[normalizedId]), {
    answer,
    acceptedAnswers,
    deleted: false,
    updatedAt
  });
  await saveDemoImageSettings(settings);
  const baseImage = (0, import_demo_images.buildDemoImages)(origin).find((image) => image.id === normalizedId);
  if (!baseImage) {
    throw new import_http.HttpError(404, "That starter image does not exist.");
  }
  return __spreadProps(__spreadValues({}, baseImage), {
    answer,
    acceptedAnswers,
    source: "demo",
    sourceLabel: DEMO_SOURCE_LABEL,
    previewUrl: baseImage.imageUrl,
    uploaderName: DEMO_UPLOADER_NAME,
    submitterIp: "",
    approvedAt: updatedAt
  });
}
async function deleteDemoCatalogImage(id) {
  const normalizedId = String(id || "").trim();
  if (!isDemoCatalogImage(normalizedId)) {
    throw new import_http.HttpError(404, "That starter image does not exist.");
  }
  const settings = await loadDemoImageSettings();
  settings[normalizedId] = __spreadProps(__spreadValues({}, settings[normalizedId]), {
    deleted: true,
    deletedAt: new Date().toISOString()
  });
  await saveDemoImageSettings(settings);
}
async function listManagedDemoImages(origin, options = {}) {
  const { forAdmin = false } = options;
  const settings = await loadDemoImageSettings();
  const baseImages = (0, import_demo_images.buildDemoImages)(origin);
  return baseImages.map((baseImage) => {
    const override = settings[baseImage.id] || {};
    if (override.deleted) {
      return null;
    }
    const answer = normalizeAnswer(override.answer) || baseImage.answer;
    const acceptedAnswers = hasOwnProperty(override, "acceptedAnswers") ? normalizeAcceptedAnswers(override.acceptedAnswers, answer) : normalizeAcceptedAnswers(baseImage.acceptedAnswers || [], answer);
    if (forAdmin) {
      return __spreadProps(__spreadValues({}, baseImage), {
        answer,
        acceptedAnswers,
        source: "demo",
        sourceLabel: DEMO_SOURCE_LABEL,
        previewUrl: baseImage.imageUrl,
        uploaderName: DEMO_UPLOADER_NAME,
        submitterIp: "",
        approvedAt: override.updatedAt || ""
      });
    }
    return __spreadProps(__spreadValues({}, baseImage), {
      answer,
      acceptedAnswers,
      source: "demo"
    });
  }).filter(Boolean);
}
async function listStoredApprovedImages(options = {}) {
  const { forAdmin = false } = options;
  if (!(0, import_storage.storageConfigured)()) {
    return [];
  }
  const approved = await (0, import_storage.listJson)("approved/meta/");
  const images = await Promise.all(approved.map(async (item) => {
    if (!item?.id || !item?.imageKey || !item?.answer) {
      return null;
    }
    if (forAdmin) {
      return __spreadProps(__spreadValues({}, item), {
        source: "approved",
        sourceLabel: APPROVED_SOURCE_LABEL,
        previewUrl: await (0, import_storage.createSignedDownloadUrl)(item.imageKey, 1800)
      });
    }
    return {
      id: item.id,
      answer: item.answer,
      acceptedAnswers: item.acceptedAnswers || [],
      imageUrl: await (0, import_storage.createSignedDownloadUrl)(item.imageKey),
      focusX: item.focusX || 50,
      focusY: item.focusY || 50,
      source: "approved"
    };
  }));
  return images.filter(Boolean);
}
async function loadDemoImageSettings() {
  if (!(0, import_storage.storageConfigured)()) {
    return {};
  }
  const document = await (0, import_storage.getJson)(DEMO_IMAGE_SETTINGS_KEY);
  const imageSettings = document?.images;
  if (!imageSettings || typeof imageSettings !== "object") {
    return {};
  }
  const normalized = {};
  for (const [id, value] of Object.entries(imageSettings)) {
    if (!isDemoCatalogImage(id) || !value || typeof value !== "object") {
      continue;
    }
    normalized[id] = {
      answer: normalizeAnswer(value.answer),
      acceptedAnswers: normalizeAcceptedAnswers(value.acceptedAnswers, value.answer),
      deleted: Boolean(value.deleted),
      updatedAt: String(value.updatedAt || ""),
      deletedAt: String(value.deletedAt || "")
    };
  }
  return normalized;
}
async function saveDemoImageSettings(settings) {
  await (0, import_storage.putJson)(DEMO_IMAGE_SETTINGS_KEY, {
    images: settings,
    updatedAt: new Date().toISOString()
  });
}
function normalizeAnswer(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 80);
}
function normalizeAcceptedAnswers(value, mainAnswer = "") {
  const parsed = Array.isArray(value) ? value : String(value || "").split(/[\n,]/).map((item) => item.trim());
  const normalizedMain = normalizeComparable(mainAnswer);
  const seen = /* @__PURE__ */ new Set();
  const unique = [];
  for (const entry of parsed) {
    const trimmed = normalizeAnswer(entry);
    const comparable = normalizeComparable(trimmed);
    if (!trimmed || !comparable || comparable === normalizedMain || seen.has(comparable)) {
      continue;
    }
    seen.add(comparable);
    unique.push(trimmed);
  }
  return unique;
}
function normalizeComparable(value) {
  return String(value || "").normalize("NFKD").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}
function hasOwnProperty(object, property) {
  return Object.prototype.hasOwnProperty.call(object, property);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  deleteDemoCatalogImage,
  isDemoCatalogImage,
  listAdminCatalogImages,
  listCatalogAnswerEntries,
  listPlayableCatalogImages,
  updateDemoCatalogImage
});
