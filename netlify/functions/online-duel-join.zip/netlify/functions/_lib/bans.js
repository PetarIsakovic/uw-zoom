var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bans_exports = {};
__export(bans_exports, {
  banIp: () => banIp,
  isIpBanned: () => isIpBanned,
  loadBannedIps: () => loadBannedIps,
  requireNotBanned: () => requireNotBanned,
  unbanIp: () => unbanIp
});
module.exports = __toCommonJS(bans_exports);
var import_http = require("./http.js");
var import_storage = require("./storage.js");
var import_ip = require("./ip.js");
const BANNED_IPS_KEY = "app/admin/banned-ips.json";
async function loadBannedIps() {
  if (!(0, import_storage.storageConfigured)()) {
    return [];
  }
  const payload = await (0, import_storage.getJson)(BANNED_IPS_KEY);
  const entries = Array.isArray(payload?.entries) ? payload.entries : [];
  return entries.map(normalizeBanEntry).filter(Boolean).sort((left, right) => Date.parse(right.bannedAt || 0) - Date.parse(left.bannedAt || 0));
}
async function isIpBanned(ip) {
  const normalizedIp = (0, import_ip.normalizeIp)(ip);
  if (!normalizedIp || normalizedIp === "Unknown") {
    return false;
  }
  const entries = await loadBannedIps();
  return entries.some((entry) => entry.ip === normalizedIp);
}
async function requireNotBanned(event, scope = "using this part of UW Zoom") {
  const ip = (0, import_ip.getClientIp)(event);
  if (await isIpBanned(ip)) {
    throw new import_http.HttpError(403, `This IP address has been banned from ${scope}.`);
  }
}
async function banIp(ip, metadata = {}) {
  const normalizedIp = (0, import_ip.normalizeIp)(ip);
  if (!normalizedIp || normalizedIp === "Unknown") {
    throw new import_http.HttpError(400, "A valid IP address is required.");
  }
  const entries = await loadBannedIps();
  const nextEntries = [
    {
      ip: normalizedIp,
      label: normalizeLabel(metadata.label),
      source: normalizeLabel(metadata.source),
      bannedAt: new Date().toISOString()
    },
    ...entries.filter((entry) => entry.ip !== normalizedIp)
  ];
  await (0, import_storage.putJson)(BANNED_IPS_KEY, {
    updatedAt: new Date().toISOString(),
    entries: nextEntries
  });
  return nextEntries;
}
async function unbanIp(ip) {
  const normalizedIp = (0, import_ip.normalizeIp)(ip);
  const entries = await loadBannedIps();
  const nextEntries = entries.filter((entry) => entry.ip !== normalizedIp);
  await (0, import_storage.putJson)(BANNED_IPS_KEY, {
    updatedAt: new Date().toISOString(),
    entries: nextEntries
  });
  return nextEntries;
}
function normalizeBanEntry(value) {
  const ip = (0, import_ip.normalizeIp)(value?.ip);
  if (!ip || ip === "Unknown") {
    return null;
  }
  return {
    ip,
    label: normalizeLabel(value?.label),
    source: normalizeLabel(value?.source),
    bannedAt: normalizeTimestamp(value?.bannedAt)
  };
}
function normalizeLabel(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 120);
}
function normalizeTimestamp(value) {
  const parsed = Date.parse(String(value || ""));
  return Number.isFinite(parsed) ? new Date(parsed).toISOString() : new Date().toISOString();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  banIp,
  isIpBanned,
  loadBannedIps,
  requireNotBanned,
  unbanIp
});
