var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var storage_exports = {};
__export(storage_exports, {
  approvedMetadataKey: () => approvedMetadataKey,
  copyObject: () => copyObject,
  createPresignedUpload: () => createPresignedUpload,
  createSignedDownloadUrl: () => createSignedDownloadUrl,
  deleteObject: () => deleteObject,
  getJson: () => getJson,
  getObjectMetadata: () => getObjectMetadata,
  getStorageConfig: () => getStorageConfig,
  listJson: () => listJson,
  objectExists: () => objectExists,
  pendingMetadataKey: () => pendingMetadataKey,
  putJson: () => putJson,
  requireStorage: () => requireStorage,
  storageConfigured: () => storageConfigured,
  toApprovedImageKey: () => toApprovedImageKey,
  validateImageSize: () => validateImageSize,
  validateImageType: () => validateImageType
});
module.exports = __toCommonJS(storage_exports);
var import_node_crypto = require("node:crypto");
var import_node_path = require("node:path");
var import_client_s3 = require("@aws-sdk/client-s3");
var import_s3_presigned_post = require("@aws-sdk/s3-presigned-post");
var import_s3_request_presigner = require("@aws-sdk/s3-request-presigner");
var import_http = require("./http.js");
const FALLBACK_MAX_UPLOAD_MB = 15;
const ALLOWED_IMAGE_TYPES = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp"]);
const EXTENSIONS_BY_TYPE = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp"
};
let cachedClient;
function storageConfigured() {
  return Boolean(resolveStorageRegion() && process.env.UWZ_S3_BUCKET);
}
function getStorageConfig() {
  const maxUploadMb = Number(process.env.UWZ_MAX_UPLOAD_MB || FALLBACK_MAX_UPLOAD_MB);
  return {
    region: resolveStorageRegion(),
    bucket: process.env.UWZ_S3_BUCKET,
    maxUploadMb: Number.isFinite(maxUploadMb) && maxUploadMb > 0 ? maxUploadMb : FALLBACK_MAX_UPLOAD_MB
  };
}
function requireStorage() {
  const config = getStorageConfig();
  if (!config.region || !config.bucket) {
    throw new import_http.HttpError(503, "AWS storage is not configured. Add UWZ_AWS_REGION, UWZ_AWS_ACCESS_KEY_ID, UWZ_AWS_SECRET_ACCESS_KEY, and UWZ_S3_BUCKET in Netlify.");
  }
  return config;
}
function validateImageType(fileType) {
  if (!ALLOWED_IMAGE_TYPES.has(fileType)) {
    throw new import_http.HttpError(400, "Only JPEG, PNG, or WebP images are supported.");
  }
}
function validateImageSize(fileSize) {
  const { maxUploadMb } = getStorageConfig();
  const bytes = Number(fileSize);
  if (!Number.isFinite(bytes) || bytes <= 0) {
    throw new import_http.HttpError(400, "A valid image size is required.");
  }
  if (bytes > maxUploadMb * 1024 * 1024) {
    throw new import_http.HttpError(400, `Keep uploads under ${maxUploadMb} MB.`);
  }
}
async function createPresignedUpload({ filename, fileType }) {
  const { bucket, maxUploadMb } = requireStorage();
  validateImageType(fileType);
  const id = (0, import_node_crypto.randomUUID)();
  const imageKey = `pending/images/${id}${resolveExtension(filename, fileType)}`;
  const expiresIn = 120;
  const maxUploadBytes = maxUploadMb * 1024 * 1024;
  const upload = await (0, import_s3_presigned_post.createPresignedPost)(getClient(), {
    Bucket: bucket,
    Key: imageKey,
    Expires: expiresIn,
    Fields: {
      "Content-Type": fileType,
      success_action_status: "204"
    },
    Conditions: [
      ["eq", "$Content-Type", fileType],
      ["eq", "$success_action_status", "204"],
      ["content-length-range", 1, maxUploadBytes]
    ]
  });
  return {
    id,
    imageKey,
    uploadMethod: "POST",
    uploadUrl: upload.url,
    uploadFields: upload.fields,
    expiresIn,
    maxUploadBytes
  };
}
function pendingMetadataKey(id) {
  return `pending/meta/${id}.json`;
}
function approvedMetadataKey(id) {
  return `approved/meta/${id}.json`;
}
async function objectExists(key) {
  const { bucket } = requireStorage();
  try {
    await getClient().send(new import_client_s3.HeadObjectCommand({
      Bucket: bucket,
      Key: key
    }));
    return true;
  } catch (error) {
    if (error?.$metadata?.httpStatusCode === 404 || error?.name === "NotFound" || error?.name === "NoSuchKey") {
      return false;
    }
    throw error;
  }
}
async function getObjectMetadata(key) {
  const { bucket } = requireStorage();
  try {
    const response = await getClient().send(new import_client_s3.HeadObjectCommand({
      Bucket: bucket,
      Key: key
    }));
    return {
      contentLength: Number(response.ContentLength || 0),
      contentType: String(response.ContentType || "")
    };
  } catch (error) {
    if (error?.$metadata?.httpStatusCode === 404 || error?.name === "NotFound" || error?.name === "NoSuchKey") {
      return null;
    }
    throw error;
  }
}
async function putJson(key, value) {
  const { bucket } = requireStorage();
  await getClient().send(new import_client_s3.PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: JSON.stringify(value, null, 2),
    ContentType: "application/json; charset=utf-8"
  }));
}
async function getJson(key) {
  const { bucket } = requireStorage();
  try {
    const response = await getClient().send(new import_client_s3.GetObjectCommand({
      Bucket: bucket,
      Key: key
    }));
    const text = await streamToString(response.Body);
    return JSON.parse(text);
  } catch (error) {
    if (error?.$metadata?.httpStatusCode === 404 || error?.name === "NoSuchKey" || error?.name === "NotFound") {
      return null;
    }
    throw error;
  }
}
async function listJson(prefix) {
  const { bucket } = requireStorage();
  const keys = [];
  let continuationToken;
  do {
    const response = await getClient().send(new import_client_s3.ListObjectsV2Command({
      Bucket: bucket,
      Prefix: prefix,
      ContinuationToken: continuationToken
    }));
    keys.push(...(response.Contents || []).map((item) => item.Key).filter(Boolean));
    continuationToken = response.IsTruncated ? response.NextContinuationToken : void 0;
  } while (continuationToken);
  const documents = await Promise.all(keys.map((key) => getJson(key)));
  return documents.filter(Boolean).sort((left, right) => new Date(right.submittedAt || right.approvedAt || 0).getTime() - new Date(left.submittedAt || left.approvedAt || 0).getTime());
}
async function createSignedDownloadUrl(key, expiresIn = 3600) {
  const { bucket } = requireStorage();
  return (0, import_s3_request_presigner.getSignedUrl)(getClient(), new import_client_s3.GetObjectCommand({
    Bucket: bucket,
    Key: key
  }), { expiresIn });
}
async function copyObject(sourceKey, destinationKey) {
  const { bucket } = requireStorage();
  await getClient().send(new import_client_s3.CopyObjectCommand({
    Bucket: bucket,
    Key: destinationKey,
    CopySource: buildCopySource(bucket, sourceKey)
  }));
}
async function deleteObject(key) {
  const { bucket } = requireStorage();
  await getClient().send(new import_client_s3.DeleteObjectCommand({
    Bucket: bucket,
    Key: key
  }));
}
function toApprovedImageKey(id, originalKey) {
  const extension = (0, import_node_path.extname)(originalKey) || ".jpg";
  return `approved/images/${id}${extension}`;
}
function getClient() {
  if (!cachedClient) {
    const { region } = requireStorage();
    const credentials = resolveStorageCredentials();
    cachedClient = new import_client_s3.S3Client(__spreadValues({
      region
    }, credentials ? { credentials } : {}));
  }
  return cachedClient;
}
function resolveExtension(filename, fileType) {
  const discovered = (0, import_node_path.extname)(String(filename || "")).toLowerCase();
  if (discovered && Object.values(EXTENSIONS_BY_TYPE).includes(discovered)) {
    return discovered;
  }
  return EXTENSIONS_BY_TYPE[fileType] || ".jpg";
}
function buildCopySource(bucket, key) {
  return `${bucket}/${key.split("/").map(encodeURIComponent).join("/")}`;
}
function resolveStorageRegion() {
  return process.env.UWZ_AWS_REGION || process.env.AWS_REGION || "";
}
function resolveStorageCredentials() {
  const accessKeyId = process.env.UWZ_AWS_ACCESS_KEY_ID || process.env.AWS_ACCESS_KEY_ID || "";
  const secretAccessKey = process.env.UWZ_AWS_SECRET_ACCESS_KEY || process.env.AWS_SECRET_ACCESS_KEY || "";
  if (!accessKeyId || !secretAccessKey) {
    return null;
  }
  return {
    accessKeyId,
    secretAccessKey
  };
}
async function streamToString(stream) {
  if (!stream) {
    return "";
  }
  if (typeof stream.transformToString === "function") {
    return stream.transformToString();
  }
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(typeof chunk === "string" ? Buffer.from(chunk) : chunk);
  }
  return Buffer.concat(chunks).toString("utf8");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  approvedMetadataKey,
  copyObject,
  createPresignedUpload,
  createSignedDownloadUrl,
  deleteObject,
  getJson,
  getObjectMetadata,
  getStorageConfig,
  listJson,
  objectExists,
  pendingMetadataKey,
  putJson,
  requireStorage,
  storageConfigured,
  toApprovedImageKey,
  validateImageSize,
  validateImageType
});
