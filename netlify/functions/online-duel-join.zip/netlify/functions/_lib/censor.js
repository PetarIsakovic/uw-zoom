var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var censor_exports = {};
__export(censor_exports, {
  censorProfanity: () => censorProfanity
});
module.exports = __toCommonJS(censor_exports);
const PROFANITY_PATTERNS = [
  /motherfucker/giu,
  /niggers?/giu,
  /niggas?/giu,
  /faggots?/giu,
  /retards?/giu,
  /assholes?/giu,
  /bitches?/giu,
  /bastards?/giu,
  /whores?/giu,
  /sluts?/giu,
  /puss(y|ies)/giu,
  /cunts?/giu,
  /dicks?/giu,
  /cocks?/giu,
  /fucks?/giu,
  /fucking/giu,
  /fucked/giu,
  /shits?/giu,
  /shitty/giu,
  /\bfag\b/giu
];
function censorProfanity(value, options = {}) {
  const maxLength = Number.isFinite(Number(options.maxLength)) ? Math.max(0, Math.floor(Number(options.maxLength))) : Number.POSITIVE_INFINITY;
  const normalized = String(value || "").trim().replace(/\s+/g, " ").slice(0, maxLength);
  return PROFANITY_PATTERNS.reduce((result, pattern) => result.replace(pattern, (match) => "#".repeat(match.length)), normalized);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  censorProfanity
});
