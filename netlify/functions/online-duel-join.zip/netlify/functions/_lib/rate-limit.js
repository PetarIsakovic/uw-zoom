var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rate_limit_exports = {};
__export(rate_limit_exports, {
  requireRateLimit: () => requireRateLimit
});
module.exports = __toCommonJS(rate_limit_exports);
var import_node_crypto = require("node:crypto");
var import_http = require("./http.js");
var import_ip = require("./ip.js");
var import_storage = require("./storage.js");
const RATE_LIMIT_PREFIX = "app/rate-limits";
async function requireRateLimit(event, scope, options = {}) {
  if (!(0, import_storage.storageConfigured)()) {
    return;
  }
  const normalizedIp = (0, import_ip.normalizeIp)((0, import_ip.getClientIp)(event));
  if (!normalizedIp || normalizedIp === "Unknown") {
    return;
  }
  const windowMs = normalizeWindowMs(options.windowMs);
  const maxRequests = normalizeMaxRequests(options.maxRequests);
  const now = Date.now();
  const key = buildRateLimitKey(scope, normalizedIp);
  const payload = await (0, import_storage.getJson)(key);
  const recentHits = Array.isArray(payload?.hits) ? payload.hits.map((value) => Number(value)).filter((value) => Number.isFinite(value) && now - value < windowMs) : [];
  if (recentHits.length >= maxRequests) {
    const retryAfterSeconds = Math.max(1, Math.ceil((recentHits[0] + windowMs - now) / 1e3));
    throw new import_http.HttpError(429, options.message || "Too many requests. Try again in a few minutes.", {
      "Retry-After": String(retryAfterSeconds)
    });
  }
  recentHits.push(now);
  await (0, import_storage.putJson)(key, {
    scope: sanitizeScope(scope),
    updatedAt: new Date(now).toISOString(),
    hits: recentHits
  });
}
function buildRateLimitKey(scope, ip) {
  const scopeSegment = sanitizeScope(scope);
  const ipHash = (0, import_node_crypto.createHash)("sha256").update(ip).digest("hex");
  return `${RATE_LIMIT_PREFIX}/${scopeSegment}/${ipHash}.json`;
}
function sanitizeScope(value) {
  return String(value || "general").trim().toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "general";
}
function normalizeWindowMs(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 10 * 60 * 1e3;
}
function normalizeMaxRequests(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 10;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  requireRateLimit
});
