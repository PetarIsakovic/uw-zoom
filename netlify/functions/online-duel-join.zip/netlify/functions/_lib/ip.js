var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ip_exports = {};
__export(ip_exports, {
  getClientIp: () => getClientIp,
  normalizeIp: () => normalizeIp
});
module.exports = __toCommonJS(ip_exports);
function getClientIp(event) {
  return normalizeIp(firstHeaderValue(event.headers["x-nf-client-connection-ip"] || event.headers["X-Nf-Client-Connection-Ip"] || event.headers["client-ip"] || event.headers["Client-Ip"] || event.headers["x-forwarded-for"] || event.headers["X-Forwarded-For"] || event.headers["cf-connecting-ip"] || event.headers["Cf-Connecting-Ip"] || ""));
}
function normalizeIp(value) {
  const normalized = String(value || "").split(",")[0].trim().replace(/^\[|\]$/g, "").replace(/^::ffff:/i, "").slice(0, 80);
  return normalized || "Unknown";
}
function firstHeaderValue(value) {
  return Array.isArray(value) ? value[0] || "" : value;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getClientIp,
  normalizeIp
});
