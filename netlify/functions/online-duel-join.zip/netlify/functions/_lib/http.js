var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var http_exports = {};
__export(http_exports, {
  HttpError: () => HttpError,
  ensureMethod: () => ensureMethod,
  getOrigin: () => getOrigin,
  handleOptions: () => handleOptions,
  json: () => json,
  parseJsonBody: () => parseJsonBody,
  withErrorHandling: () => withErrorHandling
});
module.exports = __toCommonJS(http_exports);
class HttpError extends Error {
  constructor(statusCode, message, headers = {}) {
    super(message);
    this.name = "HttpError";
    this.statusCode = statusCode;
    this.headers = headers;
  }
}
function withErrorHandling(handler) {
  return async (event) => {
    try {
      return await handler(event);
    } catch (error) {
      const statusCode = error instanceof HttpError ? error.statusCode : 500;
      const message = error instanceof HttpError ? error.message : "Something went wrong on the server.";
      const headers = error instanceof HttpError ? error.headers || {} : {};
      if (!(error instanceof HttpError)) {
        console.error(error);
      }
      return json(statusCode, { error: message }, headers);
    }
  };
}
function handleOptions(event, allowedMethods) {
  if (event.httpMethod !== "OPTIONS") {
    return null;
  }
  return {
    statusCode: 204,
    headers: {
      Allow: allowedMethods.join(", "),
      "Cache-Control": "no-store"
    }
  };
}
function ensureMethod(event, allowedMethods) {
  if (!allowedMethods.includes(event.httpMethod)) {
    throw new HttpError(405, `Method not allowed. Use ${allowedMethods.join(" or ")}.`);
  }
}
function parseJsonBody(event) {
  if (!event.body) {
    return {};
  }
  try {
    return JSON.parse(event.body);
  } catch {
    throw new HttpError(400, "Invalid JSON body.");
  }
}
function json(statusCode, body, extraHeaders = {}) {
  return {
    statusCode,
    headers: __spreadValues({
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    }, extraHeaders),
    body: JSON.stringify(body)
  };
}
function getOrigin(event) {
  if (event.rawUrl) {
    try {
      return new URL(event.rawUrl).origin;
    } catch {
    }
  }
  const proto = event.headers["x-forwarded-proto"] || event.headers["X-Forwarded-Proto"] || resolveDefaultProto(event.headers.host || event.headers.Host || "");
  const host = event.headers.host || event.headers.Host;
  if (!host) {
    throw new HttpError(500, "Unable to determine the request host.");
  }
  return `${proto}://${host}`;
}
function resolveDefaultProto(host) {
  const normalizedHost = String(host || "").toLowerCase();
  if (normalizedHost.startsWith("localhost") || normalizedHost.startsWith("127.0.0.1") || normalizedHost.startsWith("[::1]")) {
    return "http";
  }
  return "https";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HttpError,
  ensureMethod,
  getOrigin,
  handleOptions,
  json,
  parseJsonBody,
  withErrorHandling
});
