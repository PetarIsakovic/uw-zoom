var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_submissions_exports = {};
__export(admin_submissions_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_submissions_exports);
var import_admin = require("./_lib/admin.js");
var import_http = require("./_lib/http.js");
var import_storage = require("./_lib/storage.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET"]);
  (0, import_admin.requireAdmin)(event);
  const pending = await (0, import_storage.listJson)("pending/meta/");
  const submissions = await Promise.all(pending.map(async (item) => __spreadProps(__spreadValues({}, item), {
    previewUrl: await (0, import_storage.createSignedDownloadUrl)(item.imageKey, 1800)
  })));
  return (0, import_http.json)(200, {
    submissions
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
