var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_leaderboard_exports = {};
__export(admin_leaderboard_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_leaderboard_exports);
var import_admin = require("./_lib/admin.js");
var import_http = require("./_lib/http.js");
var import_leaderboard = require("./_lib/leaderboard.js");
var import_online_wins = require("./_lib/online-wins.js");
const handler = (0, import_http.withErrorHandling)(async (event) => {
  const preflight = (0, import_http.handleOptions)(event, ["GET", "POST", "OPTIONS"]);
  if (preflight) {
    return preflight;
  }
  (0, import_http.ensureMethod)(event, ["GET", "POST"]);
  (0, import_admin.requireAdmin)(event);
  if (event.httpMethod === "GET") {
    return (0, import_http.json)(200, {
      entries: await (0, import_leaderboard.loadLeaderboardEntries)(),
      onlineWins: await (0, import_online_wins.loadOnlineWinLeaders)()
    });
  }
  const body = (0, import_http.parseJsonBody)(event);
  const id = String(body.id || "").trim().toLowerCase();
  const type = String(body.type || "streak").trim().toLowerCase();
  if (!/^[a-z0-9-]{8,64}$/.test(id)) {
    throw new import_http.HttpError(400, "A valid leaderboard entry id is required.");
  }
  if (type === "online-win") {
    const entries2 = await (0, import_online_wins.loadOnlineWinLeaders)();
    if (!entries2.some((entry) => entry.id === id)) {
      throw new import_http.HttpError(404, "That online wins entry no longer exists.");
    }
    const nextEntries2 = await (0, import_online_wins.deleteOnlineWinLeader)(id);
    return (0, import_http.json)(200, {
      success: true,
      id,
      type,
      onlineWins: nextEntries2
    });
  }
  if (type !== "streak") {
    throw new import_http.HttpError(400, "A valid leaderboard type is required.");
  }
  const entries = await (0, import_leaderboard.loadLeaderboardEntries)();
  if (!entries.some((entry) => entry.id === id)) {
    throw new import_http.HttpError(404, "That leaderboard entry no longer exists.");
  }
  const nextEntries = await (0, import_leaderboard.deleteLeaderboardEntry)(id);
  return (0, import_http.json)(200, {
    success: true,
    id,
    type,
    entries: nextEntries
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
